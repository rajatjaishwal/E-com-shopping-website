const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();
const PORT = 5000;
app.use(express.json());
app.use(cors());
mongoose
  .connect("mongodb://127.0.0.1:27017/shopping", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));
const productSchema = new mongoose.Schema({
  id: Number,
  description: String,
  category: String,
  price: Number,
  dateAdded: String,
  stock: Number,
});

const Product = mongoose.model("Product", productSchema);
app.get("/api/products", async (req, res) => {
  const { category } = req.query;

  try {
    const query = category ? { category } : {};
    const products = await Product.find(query);
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch products." });
  }
});
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
