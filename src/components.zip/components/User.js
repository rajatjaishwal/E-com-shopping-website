import Banner from "./Banner";
import Home from "./Home";
import Footer from "./Footer";
function User() {
  return <div>  
    <Banner />
    <Home />
    <Footer />
  </div>;
}

export default User;
