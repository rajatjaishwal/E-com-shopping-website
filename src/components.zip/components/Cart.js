import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../style/Cart.css"; 

const Cart = ({ cart, setCart }) => {
  const [quantities, setQuantities] = useState(
    cart.reduce((acc, item) => {
      acc[item.id] = 1; 
      return acc;
    }, {})
  );

  const handleQuantityChange = (id, delta) => {
    setQuantities((prev) => {
      const updatedQuantities = { ...prev };
      const newQuantity = updatedQuantities[id] + delta;
      updatedQuantities[id] = Math.max(newQuantity, 1);
      return updatedQuantities;
    });
  };

  const calculateTotal = () => {
    return cart.reduce((total, product) => {
      return total + product.price * quantities[product.id];
    }, 0);
  };

  return (
    <div className="cart-container">
      {cart.length === 0 ? (
        <div className="empty-cart">
          <h1>Your Cart is Empty</h1>
          <Link to="/" className="btn btn-warning">
            Continue Shopping...
          </Link>
        </div>
      ) : (
        <>
          {cart.map((product) => (
            <div className="cart-item" key={product.id}>
              <div className="cart-item-img">
                <img src={product.imgSrc} alt={product.title} />
              </div>
              <div className="cart-item-details">
                <h5>{product.title}</h5>
                <p>{product.description}</p>
                <div className="cart-item-actions">
                  <button
                    className="btn btn-secondary"
                    onClick={() => handleQuantityChange(product.id, -1)}
                  >
                    -
                  </button>
                  <span className="quantity">{quantities[product.id]}</span>
                  <button
                    className="btn btn-secondary"
                    onClick={() => handleQuantityChange(product.id, 1)}
                  >
                    +
                  </button>
                  <button className="btn btn-primary">
                    {product.price * quantities[product.id]} ₹
                  </button>
                </div>
              </div>
            </div>
          ))}

          <div className="cart-footer">
            <h3>Total Cost: {calculateTotal()} ₹</h3>
            <button className="btn btn-warning">CheckOut</button>
            <button className="btn btn-danger" onClick={() => setCart([])}>
              Clear Cart
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;
