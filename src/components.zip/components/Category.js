import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import "../style/Category.css"; // External CSS for styling

const Category = ({ cart, setCart }) => {
  const { category } = useParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/products`, {
          params: { category },
        });
        setProducts(response.data);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching products:", err);
        setLoading(false);
      }
    };

    fetchProducts();
  }, [category]);

  const handleAddToCart = (product) => {
    setCart((prevCart) => [...prevCart, product]);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="category-container">
      <h2>{category.charAt(0).toUpperCase() + category.slice(1)} Collection</h2>
      {products.length > 0 ? (
        <div className="product-grid">
          {products.map((product) => (
            <div key={product.id} className="product-card">
              <img
                src={`/images/${product.category}/${product.id}.jpg`} // Image based on category and product ID
                alt={product.description}
                className="product-image"
              />
              <h3 className="product-title">{product.description}</h3>
              <p className="product-price">Price: ${product.price}</p>
              <p className="product-stock">In Stock: {product.stock}</p>
              <button
                className="add-to-cart-btn"
                onClick={() => handleAddToCart(product)}
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="no-products">No products found for {category}.</p>
      )}
    </div>
  );
};

export default Category;
