export const items = [
  {
    id: 1,
    category: "Men",
    title: "Formal",
    imgSrc: "https://i.pinimg.com/236x/55/55/46/5555465c83cd9b4203be8361a6d33be1.jpg", // Men's formal shirt
    description: "Formal wear for men",
    price: "5000",
  },
  {
    id: 10,
    category: "Men",
    title: "Formal",
    imgSrc: "https://cdn.shopify.com/s/files/1/0162/2116/files/Edgy_Ways_To_Dress_Up_For_Men_7.jpg?v=1509359300", // Men's formal shirt
    description: "Navy Formal wear for men",
    price: "5000",
  },
  {
    id: 5,
    category: "Men",
    title: "Kurta",
    imgSrc: "https://assets2.andaazfashion.com/media/catalog/product/n/a/navy-blue-silk-mens-kurta-pajama-with-embroidered-jacket-mkpa06613-1.jpg", // Men's kurta
    description: "Indian Kurta for men",
    price: "1000",
  },
  {
    id: 7,
    category: "Men",
    title: "T-Shirt",
    imgSrc: "https://i.pinimg.com/736x/3e/8b/50/3e8b50bb7520118c8c7917c3f97d9b32.jpg", // Men's polo t-shirt
    description: "Polo T-Shirt",
    price: "700",
  },
  {
    id: 2,
    category: "Women",
    title: "Suits",
    imgSrc: "https://womenplusindia.com/cdn/shop/products/3700_I.jpg?v=1672567852&width=850", // Women's suit
    description: "Suits for women",
    price: "799",
  },
  {
    id: 6,
    category: "Women",
    title: "Saree",
    imgSrc: "https://www.neerus.com/cdn/shop/files/33413185MULTICOLOR_1_1080x.jpg?v=1703499160", // Women's saree
    description: "Elegant saree",
    price: "1999",
  },
  {
    id: 3,
    category: "Women",
    title: "Formal",
    imgSrc: "https://www.powersutra.io/cdn/shop/products/1_a75541df-666b-43bc-a39c-6915f69ac69f_600x.jpg", // Women's formal attire
    description: "Formal wear for women",
    price: "1999",
  },
  {
    id: 4,
    category: "Kids",
    title: "Suits",
    imgSrc: "https://garnetclothing.com/cdn/shop/products/Hareem_5.jpg?v=1679052367&width=1080", // Kids suit
    description: "Suits for kids",
    price: "799",
  },
  {
    id: 9,
    category: "Kids",
    title: "Kurta",
    imgSrc: "https://assets.myntassets.com/dpr_1.5,q_60,w_400,c_limit,fl_progressive/assets/images/productimage/2019/6/16/0eb0f878-838d-4c61-acf5-6ce54a2cb10b1560638321878-1.jpg", // Kids kurta
    description: "Kurta for boys",
    price: "499",
  },
  {
    id: 8,
    category: "Kids",
    title: "Suits",
    imgSrc: "https://www.suratsuit.in/product-img/Kid-s-Clothing-Set-Baba-Suit-B-1688391083.jpeg", // Kids suit
    description: "Stylish suit for kids",
    price: "899",
  },
];
